import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { DataService } from '../../../services/data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MainHeaderComponent } from '../../main-header/main-header.component';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterModule, MainHeaderComponent,NgIf],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit, OnDestroy {

  userId: string = 'Guest';
  expiresAt!: string;

  sessionDuration = 60*60*10 ; // 10 minutes (in seconds)
  remainingTime: number = this.sessionDuration;
  formattedTime: string = '';
  timerInterval: any;

  @Input() notificationCount: number = 0;
  showDropdown = false;
  constructor(
    private router: Router,
    private http: HttpClient,
    private fb: FormBuilder,
    private ds: DataService,
    private route: ActivatedRoute
  ) {}
 
  navigateTo(path: string) {
    // this.router.navigate([`/header/${this.userId}/${path}`]);
    this.router.navigate([`/header/${this.userId}/${this.expiresAt}/${path}`]);

  }

  // ngOnInit() {
  //   // User ID route param se
  //   this.userId = this.route.snapshot.paramMap.get('userId') || 'Guest';
  //   this.startSessionTimer();
  // }
  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.userId = params.get('userId')!;
      this.expiresAt = params.get('expiresAt')!;
  
      const expiryTimestamp = Number(this.expiresAt);
      const currentTime = Date.now();
      this.remainingTime = Math.floor((expiryTimestamp - currentTime) / 1000);
  
      if (this.remainingTime > 0) {
        this.startSessionTimer();  // Now should work
      } else {
        alert('Session already expired. Please login again.');
        this.logout();
      }
      
    });
  }

  startSessionTimer() {
    this.updateFormattedTime();
  
    this.timerInterval = setInterval(() => {
      this.remainingTime--;
      this.updateFormattedTime();
  
      if (this.remainingTime <= 0) {
        clearInterval(this.timerInterval);
        alert('Your session time expired. Please login again....');
        this.logout();
      }
    }, 1000);
  }
  

  updateFormattedTime() {
    const hours = Math.floor(this.remainingTime / 3600);
    const minutes = Math.floor((this.remainingTime % 3600) / 60);
    const seconds = this.remainingTime % 60;
    this.formattedTime = `${this.pad(hours)}:${this.pad(minutes)}:${this.pad(seconds)}`;
  }
  

  pad(num: number): string {
    return num < 10 ? '0' + num : num.toString();
  }

  logout() {
    this.ds.postData('logout', {}).subscribe(() => {
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['/login']);
    });
  }

  ngOnDestroy() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
  }
}
